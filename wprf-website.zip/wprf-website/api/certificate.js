// GET  /api/certificate?c=TOKEN          -> is this certificate genuine?
// POST /api/certificate {paymentId,email} -> download a certificate again
import { json, keys, rzp, readToken, signToken, makeRecord } from '../lib/core.js';

const NOT_FOUND = 'We couldn\'t find a donation with that payment ID and email. Check both and try again, or email us for help.';

async function handler(req) {
  const k = keys();
  if (!k) return json({ error: 'not_configured', message: 'Certificates are not set up yet.' }, 503);

  if (req.method === 'GET') {
    const token = new URL(req.url).searchParams.get('c');
    const record = readToken(token);
    return json(record ? { valid: true, record } : { valid: false });
  }
  if (req.method !== 'POST') return json({ error: 'method' }, 405);

  let b;
  try { b = (await req.json()) || {}; } catch { return json({ error: 'invalid', message: 'Invalid request.' }, 400); }
  const pid = String(b.paymentId || '').trim();
  const email = String(b.email || '').trim().toLowerCase();
  if (!/^pay_[A-Za-z0-9]+$/.test(pid) || !email) return json({ error: 'invalid', message: NOT_FOUND }, 400);

  let payment;
  try { payment = await rzp(`/payments/${pid}`); } catch { return json({ error: 'not_found', message: NOT_FOUND }, 404); }
  const paid = Math.round((payment.amount - (payment.amount_refunded || 0)) / 100);
  let notes = { ...(payment.notes || {}) }, frequency = 'once', pledge = paid;
  try {
    if (payment.invoice_id) {
      // A monthly donation: find the subscription it belongs to.
      const inv = await rzp(`/invoices/${payment.invoice_id}`);
      if (inv.subscription_id) {
        const sub = await rzp(`/subscriptions/${inv.subscription_id}`);
        notes = { ...notes, ...(sub.notes || {}) };
        const plan = await rzp(`/plans/${sub.plan_id}`);
        frequency = 'monthly';
        pledge = Math.round(plan.item.amount / 100);
      }
    } else if (payment.order_id) {
      const order = await rzp(`/orders/${payment.order_id}`);
      notes = { ...notes, ...(order.notes || {}) };
    }
  } catch (e) {
    console.error('lookup failed', e.message);
    return json({ error: 'gateway', message: 'We couldn\'t look up this donation right now. Please try again in a few minutes.' }, 502);
  }

  const owner = String(payment.email || notes.email || '').toLowerCase();
  if (!owner || owner !== email || payment.status !== 'captured' || paid <= 0) return json({ error: 'not_found', message: NOT_FOUND }, 404);

  const record = makeRecord({ paymentId: pid, name: notes.name, amount: pledge, frequency, cause: notes.cause, created: payment.created_at });
  const receipt = notes.pan && paid >= pledge
    ? { pan: notes.pan, address: notes.address || '', amount: paid, method: payment.method || '', paymentId: pid }
    : null;
  return json({ record, token: signToken(record), receipt, paymentId: pid });
}

export default { fetch: handler };
