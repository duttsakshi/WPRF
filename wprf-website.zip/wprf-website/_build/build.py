#!/usr/bin/env python3
"""Builds the WPRF website from the files in content/ and media/.

On Vercel (inside the website repository) this runs as:   python3 _build/build.py
and writes the finished website to ./site.

In Claude's workspace it also produces the repository package and the preview page.
Only the Python standard library is needed: Jinja2 and MarkupSafe are bundled in vendor.zip.
"""
import base64, json, mimetypes, re, shutil, subprocess, sys, zipfile
from pathlib import Path
from urllib.parse import urlencode, quote

HERE = Path(__file__).resolve().parent
REPO_MODE = HERE.name == "_build"
ROOT = HERE.parent if REPO_MODE else HERE
TPL = HERE / "templates" if REPO_MODE else ROOT / "src" / "templates"
STATIC = HERE / "static" if REPO_MODE else ROOT / "src" / "static"
CONTENT = ROOT / "content"
MEDIA = ROOT / "media"
VENDOR = HERE / "vendor.zip"
if VENDOR.exists():
    sys.path.insert(0, str(VENDOR))
from jinja2 import ChainableUndefined, Environment, FileSystemLoader, select_autoescape  # noqa: E402
from markupsafe import Markup  # noqa: E402

DIST = ROOT / "dist"


# ---------------------------------------------------------------------------
# Content (edited by the professor in the editing panel, saved as JSON files)
# ---------------------------------------------------------------------------
def load(name):
    return json.loads((CONTENT / name).read_text(encoding="utf-8"))


def digits(s):
    return re.sub(r"\D", "", str(s or ""))


def tel(p):
    d = digits(p)
    return ("+" + d) if len(d) > 10 else ("+91" + d if d else "")


SETTINGS = load("settings.json")
HOME = load("home.json")
PEOPLE = load("people.json")
CLINIC = load("clinic.json")
CAMPAIGNS = load("campaigns.json")
RESEARCH = load("research.json")
JOURNAL = load("journal.json")

_s = SETTINGS


def g(d, *keys, default=""):
    """Safe lookup, so a field left empty or removed in the editing panel never breaks the build."""
    for k in keys:
        if not isinstance(d, dict) or k not in d or d[k] is None:
            return default
        d = d[k]
    return d


def num(v, default=0):
    try:
        return int(float(str(v).replace(",", "").strip()))
    except (TypeError, ValueError):
        return default


_wa = digits(g(_s, "whatsapp") or g(_s, "phone"))
if len(_wa) == 10:
    _wa = "91" + _wa
_address = [l.strip() for l in str(g(_s, "address")).splitlines() if l.strip()]
SITE = {
    "name": g(_s, "name") or "Well-being and Psychological Research Foundation", "short": g(_s, "short_name") or "WPRF",
    "domain": g(_s, "domain") or "wprf.in",
    "phone": g(_s, "phone"), "phone_tel": tel(g(_s, "phone")),
    "phone2": g(_s, "phone_2"), "phone2_tel": tel(g(_s, "phone_2")),
    "whatsapp_display": g(_s, "whatsapp") or g(_s, "phone"), "whatsapp": _wa, "wa_link": "https://wa.me/" + _wa,
    "email": g(_s, "email"), "email_alt": g(_s, "email_general"), "email_donations": g(_s, "email_donations") or g(_s, "email"),
    "email_clinic": g(_s, "email_clinic"), "email_research": g(_s, "email_research") or g(_s, "email"),
    "address_lines": _address, "hours": g(_s, "hours"),
    "maps_url": "https://www.google.com/maps/search/?api=1&query=" + quote(", ".join(_address)),
    "social": {k: g(_s, "social", k) for k in ("facebook", "instagram", "linkedin", "twitter", "youtube")},
    "register_button": g(_s, "register_button") or "Register for care",
    "forms_key": str(g(_s, "forms_key")).strip(),
    "bank": {"account_name": g(_s, "bank", "account_name"), "bank": g(_s, "bank", "bank"), "branch": g(_s, "bank", "branch"),
             "account_no": g(_s, "bank", "account_number"), "ifsc": g(_s, "bank", "ifsc"), "swift": g(_s, "bank", "swift"),
             "type": g(_s, "bank", "account_type")},
    "upi": g(_s, "upi_id"),
    "stats": {"donors": num(g(_s, "stats", "monthly_donors")), "goal": max(num(g(_s, "stats", "donor_goal"), 1), 1),
              "monthly_raised": num(g(_s, "stats", "raised_per_month"))},
    "survey": {"url": g(_s, "survey", "link"), "done": num(g(_s, "survey", "responses")),
               "goal": max(num(g(_s, "survey", "target"), 1), 1), "title": g(_s, "survey", "title"),
               "text": g(_s, "survey", "text")},
    "legal": {"pan": g(_s, "legal", "pan"), "reg_80g": g(_s, "legal", "reg_80g"),
              "reg_80g_valid": g(_s, "legal", "reg_80g_valid"), "reg_12a": g(_s, "legal", "reg_12a"),
              "cin": g(_s, "legal", "cin"), "fcra": bool(g(_s, "legal", "fcra_registered", default=False))},
    "signatory": {"name": g(_s, "certificate", "signatory_name"), "title": g(_s, "certificate", "signatory_title")},
    "signature": g(_s, "certificate", "signature_image"),
}
for _c in g(CAMPAIGNS, "campaigns", default=[]):
    _c["goal"], _c["raised"], _c["amount"] = num(_c.get("goal")), num(_c.get("raised")), num(_c.get("amount"), 500) or 500


def wa(text):
    return SITE["wa_link"] + "?text=" + quote(text)


TIERS = {
    "monthly": [
        {"amount": 10, "name": "Research supporter", "impact": "Funds 15 minutes of mental health research every month.",
         "perks": ["Monthly research updates"]},
        {"amount": 50, "name": "Education champion", "impact": "Adds up to a full therapy session every year for someone who can't afford one.",
         "perks": ["Training programme insights", "Monthly research updates"]},
        {"amount": 100, "name": "Therapy sponsor", "impact": "Helps train a community mental health worker.",
         "perks": ["Anonymous success stories", "Monthly research updates"]},
        {"amount": 500, "name": "Community leader", "impact": "Provides a therapy session every month for someone in need.",
         "perks": ["Comprehensive impact reports", "Anonymous success stories"]},
    ],
    "once": [
        {"amount": 500, "name": "Basic healing", "impact": "Provides one therapy session to someone who can't afford mental healthcare.",
         "perks": ["A 50-minute session with a professional therapist", "Assessment and a personalised support plan", "Follow-up care and progress tracking"]},
        {"amount": 2000, "name": "Transformational support", "impact": "Ensures mental healthcare for one person for a full month.",
         "perks": ["4 therapy sessions for one client", "Personalised coping strategies", "Progress tracking for sustained healing"]},
        {"amount": 5000, "name": "Community champion", "impact": "Creates community-wide mental health impact.",
         "perks": ["10 therapy sessions, or", "One mental health workshop for a community group"]},
    ],
}

PAGES = [
    ("home", "index.html", "index.html", "WPRF | Advancing mental health. Empowering minds.",
     "WPRF is a Section 8 non-profit in Pune offering affordable therapy, mental health research and an open-access psychology journal.", "home"),
    ("about", "about.html", "about.html", "About us | WPRF",
     "Our story, mission, founders and team at the Well-being and Psychological Research Foundation.", "about"),
    ("our-work", "our-work.html", "our-work.html", "Our work | WPRF",
     "Three initiatives, one mission: DearMinds clinic, our research and training institute, and our journal.", "work"),
    ("clinic", "clinic.html", "clinic.html", "DearMinds Psychological Clinic, Pune | WPRF",
     "Affordable, confidential therapy and psychological assessments in Pune and online. Register for low-cost assessment and psychotherapy.", "work"),
    ("research", "research.html", "research.html", "Research & Training Institute | WPRF",
     "Research, internships, certificate courses and workshops at the Well-being and Psychological Research Institute.", "work"),
    ("journal", "journal.html", "journal.html", "Journal of Well-being and Psychological Research | WPRF",
     "A peer-reviewed, open-access psychology journal. Aims, editorial team, issues and submission guidelines.", "work"),
    ("blog", "blog.html", "blog.html", "Insights & highlights | WPRF",
     "Mental health tips, research spotlights and news from WPRF.", "blog"),
    ("get-involved", "get-involved.html", "get-involved.html", "Get involved | WPRF",
     "Donate, volunteer or partner with WPRF to make mental healthcare accessible for all.", "involved"),
    ("donate", "donate.html", "donate.html", "Donate | WPRF",
     "Donate from ₹10 a month. 80G tax benefit, secure payment by Razorpay and an instant donor certificate.", "donate"),
    ("contact", "contact.html", "contact.html", "Contact us | WPRF",
     "Call, WhatsApp, email or visit WPRF and DearMinds clinic in Pune.", "contact"),
    ("certificate", "certificate.html", "certificate.html", "Donor certificates | WPRF",
     "Download your donor certificate again or check that a WPRF certificate is genuine.", ""),
    ("privacy", "privacy-policy.html", "privacy.html", "Privacy policy | WPRF", "How WPRF collects, uses and protects your information.", ""),
    ("terms", "terms.html", "terms.html", "Terms and conditions | WPRF", "Terms for using the WPRF website and donating online.", ""),
    ("refund", "refund-policy.html", "refund.html", "Donation refund and cancellation policy | WPRF", "When and how WPRF refunds donations and cancels monthly gifts.", ""),
    ("not-found", "404.html", "404.html", "Page not found | WPRF", "This page doesn't exist.", ""),
]
CATEGORIES = [("stress-anxiety", "Stress & anxiety"), ("relationships", "Relationships & family"),
              ("youth", "Youth & adolescents"), ("therapy", "Therapy & healing"),
              ("research", "Psychology research"), ("news", "Foundation news")]


CAT_LABEL = dict(CATEGORIES)


def load_posts():
    posts = []
    for f in sorted((CONTENT / "posts").glob("*.json")):
        p = json.loads(f.read_text(encoding="utf-8"))
        slug = re.sub(r"[^a-z0-9-]+", "-", f.stem.lower()).strip("-")
        p.update(slug=slug, route="post-" + slug, file="blog-" + slug + ".html",
                 cat_label=CAT_LABEL.get(p.get("category"), "Insights"),
                 minutes=p.get("reading_time") or 3, art=p.get("cover_style") or "a")
        posts.append(p)
    # newest date first; posts without a date keep the "order" number
    posts.sort(key=lambda p: (p.get("date") or "", -(p.get("order") or 0)), reverse=True)
    return posts


POSTS = load_posts()
for _p in POSTS:
    PAGES.append((_p["route"], _p["file"], "post.html", _p["title"] + " | WPRF", _p.get("summary", ""), "blog"))
FILE_OF = {p[0]: p[1] for p in PAGES}


ICONS = {
    "phone": '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/>',
    "chat": '<path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/><path d="M8 12h.01M12 12h.01M16 12h.01"/>',
    "mail": '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>',
    "pin": '<path d="M20 10c0 5-5.54 10.19-7.4 11.8a1 1 0 0 1-1.2 0C9.54 20.19 4 15 4 10a8 8 0 0 1 16 0"/><circle cx="12" cy="10" r="3"/>',
    "clock": '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
    "check": '<path d="M20 6 9 17l-5-5"/>',
    "shield": '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/>',
    "lock": '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
    "award": '<circle cx="12" cy="8" r="6"/><path d="M15.48 12.89 17 22l-5-3-5 3 1.52-9.11"/>',
    "receipt": '<path d="M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z"/><path d="M8 8h8M8 12h8M8 16h5"/>',
    "download": '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5"/><path d="M12 15V3"/>',
    "share": '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="m8.59 13.51 6.83 3.98M15.41 6.51l-6.82 3.98"/>',
    "copy": '<rect x="8" y="8" width="14" height="14" rx="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>',
    "menu": '<path d="M4 6h16M4 12h16M4 18h16"/>',
    "close": '<path d="M18 6 6 18M6 6l12 12"/>',
    "chevron": '<path d="m6 9 6 6 6-6"/>',
    "heart": '<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/>',
    "book": '<path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>',
    "flask": '<path d="M10 2v7.31M14 9.3V2M8.5 2h7M14 9.3a6.5 6.5 0 1 1-4 0M5.52 16h12.96"/>',
    "external": '<path d="M15 3h6v6M10 14 21 3M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>',
    "alert": '<circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/>',
    "users": '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
    "sprout": '<path d="M7 20h10M10 20c5.5-2.5.8-6.4 3-10"/><path d="M9.5 9.4c1.1.8 1.8 2.2 2.3 3.7-2 .4-3.5.4-4.8-.3-1.2-.6-2.3-1.9-3-4.2 2.8-.5 4.4 0 5.5.8z"/><path d="M14.1 6a7 7 0 0 0-1.1 4c1.9-.1 3.3-.6 4.3-1.4 1-1 1.6-2.3 1.7-4.6-2.7.1-4 1-4.9 2z"/>',
    "calendar": '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
    "globe": '<circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>',
}

def icon(name, cls="icon", label=None):
    aria = f'role="img" aria-label="{label}"' if label else 'aria-hidden="true"'
    return Markup(f'<svg class="{cls}" viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" '
                  f'stroke-width="2" stroke-linecap="round" stroke-linejoin="round" {aria}>{ICONS[name]}</svg>')

def inr(n):
    """Indian digit grouping: 150000 -> 1,50,000"""
    s = str(int(n))
    if len(s) <= 3:
        return s
    head, tail = s[:-3], s[-3:]
    parts = []
    while len(head) > 2:
        parts.insert(0, head[-2:]); head = head[:-2]
    if head:
        parts.insert(0, head)
    return ",".join(parts) + "," + tail



def initials(name):
    parts = [w for w in re.sub(r"^(Dr|Prof|Mr|Ms|Mrs)\.?\s+", "", name or "").split() if w]
    return "".join(w[0] for w in parts[:2]).upper()


def paras(text):
    return Markup("".join("<p>" + Markup.escape(p.strip()) + "</p>" for p in str(text or "").split("\n\n") if p.strip()))


def make_env(mode, host="vercel"):
    env = Environment(loader=FileSystemLoader(str(TPL)), autoescape=select_autoescape(["html"]),
                      trim_blocks=True, lstrip_blocks=True, undefined=ChainableUndefined)
    cache = {}

    def href(page, anchor=None, **params):
        if mode == "site":
            url = FILE_OF[page]
            if params:
                url += "?" + urlencode(params)
            if anchor:
                url += "#" + anchor
            return Markup('href="%s"' % url)
        attrs = 'href="#%s"' % page
        for k, v in params.items():
            attrs += ' data-%s="%s"' % (k, v)
        if anchor:
            attrs += ' data-scroll="%s"' % anchor
        return Markup(attrs)

    def data_uri(path):
        if path not in cache:
            data = path.read_bytes()
            mime = mimetypes.guess_type(str(path))[0] or "application/octet-stream"
            cache[path] = "data:%s;base64,%s" % (mime, base64.b64encode(data).decode())
        return cache[path]

    def asset(path):
        return "assets/" + path if mode == "site" else data_uri(STATIC / path)

    def img(path):
        """A picture chosen in the editing panel, e.g. /media/images/photo.jpg"""
        path = str(path or "").strip()
        if not path:
            return ""
        if path.startswith("http"):
            return path
        rel = path.lstrip("/")
        if mode == "site":
            return rel
        f = ROOT / rel
        return data_uri(f) if f.exists() else ""

    def media_link(path):
        path = str(path or "").strip()
        if not path or path.startswith("http"):
            return path
        return path.lstrip("/") if mode == "site" else "https://" + SITE["domain"] + "/" + path.lstrip("/")

    env.globals.update(href=href, asset=asset, img=img, media_link=media_link, icon=icon, MODE=mode, S=SITE,
                       HOME=HOME, PEOPLE=PEOPLE, CLINIC=CLINIC, CAMPAIGNS=CAMPAIGNS, RESEARCH=RESEARCH,
                       JOURNAL=JOURNAL, POSTS=POSTS, CATEGORIES=CATEGORIES, TIERS=TIERS, FILE_OF=FILE_OF,
                       inr=inr, wa=wa, initials=initials, paras=paras, YEAR=2026, HOST=host)
    env.filters["inr"] = inr
    env.filters["paras"] = paras
    return env


def config_js(mode, host="vercel"):
    cfg = {
        "mode": mode,
        "forms": {"provider": "netlify" if host == "netlify" else "web3forms", "key": SITE["forms_key"]},
        "orgName": SITE["name"], "short": SITE["short"], "domain": SITE["domain"],
        "logo": "assets/img/logo-512.png",
        "address": ", ".join(SITE["address_lines"]),
        "email": SITE["email"], "phone": SITE["phone"],
        "legal": SITE["legal"], "signatory": SITE["signatory"],
        "signature": SITE["signature"].lstrip("/") if SITE["signature"] else "",
        "upi": SITE["upi"], "upiName": SITE["bank"]["account_name"],
        "stats": SITE["stats"],
        "minAmount": 10, "maxAmount": 500000,
        "causes": {"general": "Where it's needed most", "therapy": "Therapy Access Fund",
                   "youth": "Youth Mental Health Research", "training": "Community Training"},
        "tiers": TIERS,
    }
    if mode == "preview":
        cfg["logo"] = "data:image/png;base64," + base64.b64encode((STATIC / "img/logo-256.png").read_bytes()).decode()
        cfg["signature"] = ""
    return "window.WPRF_CONFIG = " + json.dumps(cfg, indent=2, ensure_ascii=False) + ";\n"


def render(env, tpl, route, title, desc, nav, **extra):
    ctx = dict(route=route, page_title=title, description=desc, nav=nav)
    if tpl == "post.html":
        ctx["post"] = next(p for p in POSTS if p["route"] == route)
    ctx.update(extra)
    return env.get_template("pages/" + tpl).render(**ctx)


def build_site(out, host="vercel"):
    """Writes the finished website into `out`."""
    env = make_env("site", host)
    if out.exists():
        shutil.rmtree(out)
    (out / "assets").mkdir(parents=True)
    for sub in ("css", "js", "img", "fonts", "vendor"):
        shutil.copytree(STATIC / sub, out / "assets" / sub)
    if MEDIA.exists():
        shutil.copytree(MEDIA, out / "media")
    (out / "assets" / "js" / "config.js").write_text(config_js("site", host), encoding="utf-8")
    for route, fname, tpl, title, desc, nav in PAGES:
        html = render(env, tpl, route, title, desc, nav)
        (out / fname).write_text(re.sub(r"\n\s*\n+", "\n", html), encoding="utf-8")
    dom = "https://" + SITE["domain"] + "/"
    (out / "robots.txt").write_text("User-agent: *\nAllow: /\nSitemap: " + dom + "sitemap.xml\n")
    urls = "".join("<url><loc>%s%s</loc></url>" % (dom, "" if f == "index.html" else f) for r, f, *_ in PAGES if r != "not-found")
    (out / "sitemap.xml").write_text('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' + urls + "</urlset>\n")
    print("site ->", out, "(%d pages)" % len(PAGES))


# ---------------------------------------------------------------------------
# Workspace only: preview page and the website repository package
# ---------------------------------------------------------------------------
def build_preview():
    env = make_env("preview")
    sections = []
    for route, fname, tpl, title, desc, nav in PAGES:
        if route == "not-found":
            continue
        body = render(env, tpl, route, title, desc, nav, BARE=True)
        hidden = "" if route == "home" else " hidden"
        sections.append('<div class="route" data-route="%s" data-title="%s" data-nav="%s"%s>%s</div>' % (route, Markup.escape(title), nav, hidden, body))
    css = (STATIC / "css/site.css").read_text()
    js = "\n".join((STATIC / "js" / f).read_text() for f in ("main.js", "certificate.js", "donate.js"))
    shell = env.get_template("preview_shell.html").render(
        css=Markup(css), js=Markup(js), config=Markup(config_js("preview")), routes=Markup("\n".join(sections)),
        route="home", nav="home")
    shell = re.sub(r"\n\s*\n+", "\n", shell)
    (DIST / "preview.html").write_text(shell, encoding="utf-8")
    print("preview ->", DIST / "preview.html", round(len(shell) / 1024), "KB")


def vercel_functions():
    """Vercel versions of the server functions, generated from netlify/ (the source of truth)."""
    out = {"lib/core.js": (ROOT / "netlify/lib/core.mjs").read_text()}
    for f in sorted((ROOT / "netlify/functions").glob("*.mjs")):
        code = f.read_text().replace("'../lib/core.mjs'", "'../lib/core.js'")
        code, n1 = re.subn(r"export default async \(req\) => \{", "async function handler(req) {", code)
        code, n2 = re.subn(r"\};\s*export const config = \{ path: '[^']+' \};\s*$", "}\n\nexport default { fetch: handler };\n", code)
        assert n1 == 1 and n2 == 1, f
        out["api/" + f.stem + ".js"] = code
    return out


def build_repo_package():
    pkg = DIST / "wprf-website"
    if pkg.exists():
        shutil.rmtree(pkg)
    pkg.mkdir(parents=True)
    shutil.copytree(CONTENT, pkg / "content")
    shutil.copytree(MEDIA, pkg / "media")
    shutil.copytree(TPL, pkg / "_build" / "templates")
    shutil.copytree(STATIC, pkg / "_build" / "static")
    shutil.copy(ROOT / "build.py", pkg / "_build" / "build.py")
    shutil.copy(ROOT / "vendor.zip", pkg / "_build" / "vendor.zip")
    for rel, code in vercel_functions().items():
        (pkg / rel).parent.mkdir(parents=True, exist_ok=True)
        (pkg / rel).write_text(code)
    for name in ("vercel.json", ".pages.yml", "SETUP-GUIDE.html", "EDITING-GUIDE.html"):
        if (ROOT / "repo" / name).exists():
            shutil.copy(ROOT / "repo" / name, pkg / name)
    (pkg / "package.json").write_text('{\n  "name": "wprf-website",\n  "private": true,\n  "type": "module",\n  "engines": { "node": ">=20" }\n}\n')
    (pkg / ".gitignore").write_text("site/\n__pycache__/\n.DS_Store\n")
    # Build the package exactly the way Vercel will: bundled libraries only, no site-packages.
    subprocess.run([sys.executable, "-I", "-S", str(pkg / "_build" / "build.py")], check=True, cwd=pkg)
    print("package ->", pkg)


if __name__ == "__main__":
    if REPO_MODE:
        build_site(ROOT / "site", "vercel")
    else:
        DIST.mkdir(exist_ok=True)
        build_repo_package()
        build_preview()
