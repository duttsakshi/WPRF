// POST /api/confirm  -> verifies Razorpay's signature, then issues a signed certificate
import { json, keys, rzp, hmacHex, safeEqual, makeRecord, signToken } from '../lib/core.mjs';

export default async (req) => {
  if (req.method !== 'POST') return json({ error: 'method' }, 405);
  const k = keys();
  if (!k) return json({ error: 'not_configured', message: 'Online payments are not set up yet.' }, 503);
  let b;
  try { b = (await req.json()) || {}; } catch { return json({ error: 'invalid', message: 'Invalid request.' }, 400); }
  const pid = String(b.razorpay_payment_id || '');
  const sig = String(b.razorpay_signature || '');
  const oid = b.razorpay_order_id ? String(b.razorpay_order_id) : '';
  const sid = b.razorpay_subscription_id ? String(b.razorpay_subscription_id) : '';
  if (!/^pay_[A-Za-z0-9]+$/.test(pid) || !sig || (!oid && !sid)) return json({ error: 'invalid', message: 'Invalid payment details.' }, 400);

  // 1. The signature proves the payment details really came from Razorpay.
  const expected = hmacHex(k.secret, oid ? `${oid}|${pid}` : `${pid}|${sid}`);
  if (!safeEqual(expected, sig)) return json({ error: 'signature', message: 'We could not verify this payment.' }, 400);

  try {
    // 2. Read the payment and our own notes back from Razorpay, never from the browser.
    const payment = await rzp(`/payments/${pid}`);
    let notes = {}, frequency, pledge;
    if (oid) {
      if (payment.order_id !== oid) return json({ error: 'mismatch', message: 'Payment does not match this donation.' }, 400);
      const order = await rzp(`/orders/${oid}`);
      notes = order.notes || {};
      frequency = 'once';
      if (payment.status === 'authorized') {
        try {
          await rzp(`/payments/${pid}/capture`, { method: 'POST', body: { amount: payment.amount, currency: payment.currency } });
        } catch (e) { console.warn('capture failed', e.message); }
        Object.assign(payment, await rzp(`/payments/${pid}`));
      }
      if (payment.status !== 'captured') {
        return json({ error: 'pending', message: 'Your payment is still being processed.' }, 409);
      }
      pledge = Math.round(payment.amount / 100);
    } else {
      const sub = await rzp(`/subscriptions/${sid}`);
      notes = sub.notes || {};
      const plan = await rzp(`/plans/${sub.plan_id}`);
      frequency = 'monthly';
      pledge = Math.round(plan.item.amount / 100);
    }
    if (!['captured', 'authorized'].includes(payment.status)) {
      return json({ error: 'not_paid', message: 'This payment has not been completed.' }, 400);
    }
    const record = makeRecord({
      paymentId: pid, name: notes.name || payment.notes?.name, amount: pledge,
      frequency, cause: notes.cause || payment.notes?.cause, created: payment.created_at,
    });
    const paid = Math.round((payment.amount - (payment.amount_refunded || 0)) / 100);
    const receipt = notes.pan && payment.status === 'captured' && paid >= pledge
      ? { pan: notes.pan, address: notes.address || '', amount: paid, method: payment.method || '', paymentId: pid }
      : null;
    return json({ record, token: signToken(record), receipt, paymentId: pid });
  } catch (err) {
    console.error('confirm failed:', err.status, err.message);
    return json({ error: 'gateway', message: 'Could not confirm the payment right now.' }, 502);
  }
};

export const config = { path: '/api/confirm' };
