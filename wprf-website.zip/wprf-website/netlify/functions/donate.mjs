// POST /api/donate  -> creates a Razorpay order (one-time) or subscription (monthly)
import { json, keys, rzp, validateDonation } from '../lib/core.mjs';

async function monthlyPlan(amount) {
  // Re-use one plan per amount; create it the first time someone gives that amount.
  for (let skip = 0; skip < 1000; skip += 100) {
    const list = await rzp(`/plans?count=100&skip=${skip}`);
    const items = list.items || [];
    const hit = items.find((p) => p.period === 'monthly' && p.interval === 1 && p.item?.amount === amount * 100
      && p.item?.currency === 'INR' && p.notes?.wprf === 'monthly-donation');
    if (hit) return hit;
    if (items.length < 100) break;
  }
  return rzp('/plans', {
    method: 'POST',
    body: {
      period: 'monthly', interval: 1,
      item: { name: `Monthly donation of Rs ${amount}`, amount: amount * 100, currency: 'INR', description: 'WPRF monthly donation' },
      notes: { wprf: 'monthly-donation' },
    },
  });
}

export default async (req) => {
  if (req.method !== 'POST') return json({ error: 'method' }, 405);
  const k = keys();
  if (!k) return json({ error: 'not_configured', message: 'Online payments are not set up yet.' }, 503);
  let body;
  try { body = await req.json(); } catch { return json({ error: 'invalid', message: 'Invalid request.' }, 400); }
  const v = validateDonation(body || {});
  if (v.error) return json({ error: 'invalid', message: v.error }, 400);
  const d = v.data;
  const notes = {
    source: 'wprf-website', name: d.name, email: d.email, phone: d.phone, cause: d.cause,
    frequency: d.frequency, pan: d.pan, address: d.address, citizen: d.citizen ? 'yes' : 'no',
  };
  try {
    if (d.frequency === 'once') {
      const order = await rzp('/orders', {
        method: 'POST',
        body: { amount: d.amount * 100, currency: 'INR', receipt: `wprf_${Date.now()}`, notes },
      });
      return json({ keyId: k.id, orderId: order.id, amountPaise: order.amount });
    }
    const plan = await monthlyPlan(d.amount);
    const sub = await rzp('/subscriptions', {
      method: 'POST',
      body: { plan_id: plan.id, total_count: 60, quantity: 1, customer_notify: 1, notes },
    });
    return json({ keyId: k.id, subscriptionId: sub.id });
  } catch (err) {
    console.error('donate failed:', err.status, err.message);
    const msg = d.frequency === 'monthly' && /subscription|plan/i.test(err.message)
      ? 'Monthly giving isn\'t available right now. Please make a one-time gift, or try again later.'
      : 'The payment gateway isn\'t responding. Please try again in a minute, or give by UPI or bank transfer.';
    return json({ error: 'gateway', message: msg }, 502);
  }
};

export const config = { path: '/api/donate' };
