/* WPRF donation flow: choose amount -> details -> Razorpay -> verified certificate. */
(function () {
  'use strict';
  var form = document.getElementById('donate-form');
  if (!form) return;
  var CFG = window.WPRF_CONFIG || {};
  var W = window.WPRF = window.WPRF || {};
  var PREVIEW = CFG.mode === 'preview';
  var MIN = CFG.minAmount || 10, MAX = CFG.maxAmount || 500000;
  var $ = function (id) { return document.getElementById(id); };
  var els = {
    otherWrap: $('other-wrap'), other: $('d-other'), cause: $('d-cause'),
    want80g: $('d-80g'), f80g: $('d-80g-fields'), pan: $('d-pan'), address: $('d-address'),
    name: $('d-name'), email: $('d-email'), phone: $('d-phone'), citizen: $('d-citizen'),
    payBtn: $('pay-btn'), payLabel: $('pay-label'), summary: $('pay-summary'), monthlyNote: $('monthly-note'), alert: $('donate-alert'),
    impAmount: $('impact-amount'), impName: $('impact-name'), impText: $('impact-text'), impPerks: $('impact-perks'),
    success: $('donate-success')
  };
  var inr = function (n) { return Number(n).toLocaleString('en-IN'); };
  var esc = function (s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };

  function freq() { return form.querySelector('input[name="freq"]:checked').value; }
  function grid(f) { return form.querySelector('.amount-grid[data-freq="' + (f || freq()) + '"]'); }
  function amountChoice() { var c = grid().querySelector('input:checked'); return c ? c.value : null; }
  function amount() {
    var c = amountChoice();
    if (c === 'other') return parseInt(String(els.other.value).replace(/[^0-9]/g, ''), 10) || 0;
    return parseInt(c, 10) || 0;
  }
  function tier(f, a) { return ((CFG.tiers || {})[f] || []).filter(function (t) { return t.amount === a; })[0]; }
  function causeText() {
    var v = els.cause.value;
    return v === 'general' ? 'where it\'s needed most' : 'the ' + (CFG.causes || {})[v];
  }

  function update() {
    var f = freq();
    ['monthly', 'once'].forEach(function (k) { grid(k).hidden = k !== f; });
    els.otherWrap.hidden = amountChoice() !== 'other';
    var hint = document.getElementById('d-other-hint');
    if (hint) hint.textContent = f === 'monthly' ? 'Monthly gifts can be ₹10, or any multiple of ₹50 up to ₹10,000.' : 'Minimum ₹10.';
    var a = amount(), t = tier(f, a), monthly = f === 'monthly';
    var valid = a >= MIN && a <= MAX;
    els.impAmount.textContent = a ? '₹' + inr(a) + (monthly ? ' a month' : '') : (monthly ? 'Your monthly gift' : 'Your gift');
    var perks;
    if (t) {
      els.impName.textContent = t.name;
      els.impText.textContent = t.impact;
      perks = t.perks;
    } else {
      els.impName.textContent = monthly ? 'Monthly supporter' : 'Your gift';
      var sessions = Math.floor((monthly ? a * 12 : a) / 500);
      var plural = ' therapy session' + (sessions > 1 ? 's' : '');
      var text;
      if (!a) text = 'Enter an amount to see what it can do.';
      else if (monthly) text = 'Over a year, your gift adds up to ₹' + inr(a * 12) + (sessions ? ', enough for about ' + sessions + plural + '.' : ' for mental health research and care.');
      else text = sessions ? 'Your gift can fund about ' + sessions + plural + ' for people who can\'t afford them.' : 'Every rupee helps fund therapy, research and awareness.';
      els.impText.textContent = text;
      perks = monthly ? ['Monthly research updates', 'Impact reports'] : ['Regular impact updates'];
    }
    els.impPerks.innerHTML = perks.map(function (p) { return '<li>' + esc(p) + '</li>'; }).join('');
    els.payLabel.textContent = valid ? 'Donate ₹' + inr(a) + (monthly ? ' a month' : '') : 'Donate';
    els.summary.innerHTML = valid
      ? 'You\'re giving <strong>₹' + inr(a) + (monthly ? ' every month' : '') + '</strong> to ' + esc(causeText()) + '.'
      : 'Choose an amount of ₹' + MIN + ' or more.';
    els.monthlyNote.hidden = !monthly;
  }

  function applyPreset(p) {
    if (!p) return;
    if (p.freq === 'monthly' || p.freq === 'once') form.querySelector('input[name="freq"][value="' + p.freq + '"]').checked = true;
    var a = parseInt(p.amount, 10);
    if (a) {
      var g = grid(), r = g.querySelector('input[value="' + a + '"]');
      if (r) r.checked = true;
      else { g.querySelector('input[value="other"]').checked = true; els.other.value = a; }
    }
    if (p.cause && Array.prototype.some.call(els.cause.options, function (o) { return o.value === p.cause; })) els.cause.value = p.cause;
    update();
  }

  form.addEventListener('change', function (e) {
    if (e.target.name === 'freq') {
      // keep the amount sensible when switching
      var g = grid();
      if (!g.querySelector('input:checked')) g.querySelector('input').checked = true;
    }
    if (e.target === els.want80g) {
      els.f80g.hidden = !els.want80g.checked;
      els.pan.required = els.address.required = els.want80g.checked;
    }
    update();
    if (e.target.value === 'other' && e.target.checked) els.other.focus();
  });
  els.other.addEventListener('input', update);
  els.pan.addEventListener('input', function () { els.pan.value = els.pan.value.toUpperCase().replace(/[^A-Z0-9]/g, ''); });

  // Presets from links: ?freq=monthly&amount=10&cause=therapy (site) or route events (preview)
  if (!PREVIEW) {
    var q = new URLSearchParams(location.search);
    applyPreset({ freq: q.get('freq'), amount: q.get('amount'), cause: q.get('cause') });
    document.addEventListener('click', function (e) {
      var a = e.target.closest('a[href^="donate.html?"]');
      if (!a) return;
      e.preventDefault();
      var u = new URLSearchParams(a.getAttribute('href').split('?')[1].split('#')[0]);
      resetToForm();
      applyPreset({ freq: u.get('freq'), amount: u.get('amount'), cause: u.get('cause') });
      document.getElementById('give').scrollIntoView({ block: 'start' });
    });
  } else {
    document.addEventListener('wprf:route', function (e) {
      if (e.detail.route === 'donate' && e.detail.preset && (e.detail.preset.amount || e.detail.preset.freq)) {
        resetToForm();
        applyPreset(e.detail.preset);
        if (e.detail.preset.amount) document.getElementById('give').scrollIntoView({ block: 'start' });
      }
    });
  }
  update();

  /* ---------- UPI QR ---------- */
  function drawUpi() {
    var box = document.getElementById('upi-qr');
    if (!box || !W.qrSvg) return;
    var uri = 'upi://pay?pa=' + CFG.upi + '&pn=' + encodeURIComponent(CFG.upiName || CFG.orgName) + '&cu=INR';
    box.innerHTML = W.qrSvg(uri);
  }
  if (document.readyState === 'complete') drawUpi(); else window.addEventListener('load', drawUpi);

  /* ---------- Validation ---------- */
  function check(el) {
    var v = (el.value || '').trim();
    if (el === els.other && amountChoice() === 'other') {
      var a = amount();
      if (!a) return 'Enter an amount in rupees.';
      if (a < MIN) return 'The minimum donation is ₹' + MIN + '.';
      if (a > MAX) return 'For gifts above ₹' + inr(MAX) + ', please use bank transfer below.';
      if (freq() === 'monthly' && !(a === 10 || (a % 50 === 0 && a <= 10000))) return 'Monthly gifts can be ₹10, or any multiple of ₹50 up to ₹10,000.';
    }
    if (el === els.name && v && v.replace(/[^A-Za-zऀ-ॿ]/g, '').length < 2) return 'Enter your full name.';
    if (el === els.phone && v) {
      var d = v.replace(/\D/g, '').replace(/^(91|0)(?=\d{10}$)/, '');
      if (!/^[6-9]\d{9}$/.test(d)) return 'Enter a 10-digit Indian mobile number.';
    }
    if (el === els.pan && els.want80g.checked && v && !/^[A-Z]{5}[0-9]{4}[A-Z]$/.test(v.toUpperCase())) return 'A PAN has 10 characters, like ABCDE1234F.';
    if (el === els.address && els.want80g.checked && v && v.length < 10) return 'Enter your full address.';
    return '';
  }

  function showAlert(html, kind) {
    els.alert.hidden = false;
    els.alert.className = 'form-alert' + (kind === 'info' ? ' is-info' : '');
    els.alert.innerHTML = html;
  }
  function busy(on, label) {
    els.payBtn.disabled = on;
    if (on) els.payLabel.textContent = label || 'Please wait…';
    else update();
  }
  function payload() {
    return {
      frequency: freq(), amount: amount(), cause: els.cause.value,
      name: els.name.value.trim(), email: els.email.value.trim(),
      phone: els.phone.value.replace(/\D/g, '').replace(/^(91|0)(?=\d{10}$)/, ''),
      pan: els.want80g.checked ? els.pan.value.trim().toUpperCase() : '',
      address: els.want80g.checked ? els.address.value.trim() : '',
      citizen: els.citizen ? els.citizen.checked : true
    };
  }

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    els.alert.hidden = true;
    if (!W.validate(form, check)) return;
    var p = payload();
    if (PREVIEW) return demoPay(p);
    busy(true, 'Opening secure payment…');
    fetch('api/donate', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(p) })
      .then(function (res) { return res.json().catch(function () { return {}; }).then(function (d) { return { ok: res.ok, status: res.status, d: d }; }); })
      .then(function (x) {
        if (!x.ok) {
          busy(false);
          if (x.d.error === 'not_configured' || x.status === 404) {
            showAlert('Online card and UPI payments are being set up. For now, please give by <a href="#other-ways">UPI or bank transfer</a>.', 'info');
          } else {
            showAlert(esc(x.d.message || 'Something went wrong while starting the payment. Please try again.'));
          }
          return;
        }
        return W.loadScript('https://checkout.razorpay.com/v1/checkout.js').then(function () { openCheckout(x.d, p); });
      })
      .catch(function () {
        busy(false);
        showAlert('We couldn\'t reach the payment server. Check your internet connection and try again, or give by <a href="#other-ways">UPI or bank transfer</a>.');
      });
  });

  function openCheckout(d, p) {
    var logo = new URL(CFG.logo || 'assets/img/logo-256.png', location.href).href;
    var opts = {
      key: d.keyId,
      name: CFG.orgName,
      description: (p.frequency === 'monthly' ? 'Monthly donation' : 'Donation') + (p.cause !== 'general' ? ' – ' + (CFG.causes || {})[p.cause] : ''),
      image: logo,
      prefill: { name: p.name, email: p.email, contact: '+91' + p.phone },
      notes: { name: p.name, cause: p.cause, frequency: p.frequency },
      theme: { color: '#0B6B35' },
      handler: function (resp) { confirmPayment(resp); },
      modal: {
        ondismiss: function () {
          busy(false);
          showAlert('Payment cancelled. No money was taken. You can try again whenever you\'re ready.', 'info');
        }
      }
    };
    if (d.subscriptionId) opts.subscription_id = d.subscriptionId;
    else { opts.order_id = d.orderId; opts.amount = d.amountPaise; opts.currency = 'INR'; }
    var rzp = new window.Razorpay(opts);
    rzp.on('payment.failed', function (r) {
      var why = r && r.error && r.error.description ? esc(r.error.description) + ' ' : '';
      showAlert('The payment didn\'t go through. ' + why + 'No money was taken. Try again, or give by <a href="#other-ways">UPI or bank transfer</a>.');
    });
    busy(true, 'Complete the payment in the Razorpay window…');
    rzp.open();
  }

  function confirmPayment(resp) {
    busy(true, 'Confirming your donation…');
    fetch('api/confirm', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(resp) })
      .then(function (res) { return res.json().then(function (d) { return { ok: res.ok, d: d }; }); })
      .then(function (x) {
        if (!x.ok) throw new Error(x.d.message || 'confirm failed');
        showSuccess(x.d, false);
      })
      .catch(function () {
        busy(false);
        showAlert('Your payment went through, but we couldn\'t create your certificate just now. Your donation is safe. Note your payment ID <strong>' +
          esc(resp.razorpay_payment_id) + '</strong> and get your certificate from the <a href="certificate.html">certificates page</a>, or email us at ' + esc(CFG.email) + '.', 'info');
      });
  }

  function demoPay(p) {
    busy(true, 'Opening secure payment…');
    showAlert('Preview mode: on the live site, Razorpay\'s secure payment window opens now. No money is taken here.', 'info');
    setTimeout(function () {
      var rec = W.sampleRecord(p.name, p.amount, p.frequency === 'monthly' ? 'm' : 'o', p.cause);
      showSuccess({ record: rec, token: 'SAMPLE', paymentId: 'pay_DEMO' + rec.i.slice(-6), receipt: p.pan ? { pan: p.pan, address: p.address, amount: p.amount } : null }, true);
    }, 1100);
  }

  function showSuccess(d, demo) {
    var r = d.record;
    busy(false);
    els.alert.hidden = true;
    form.hidden = true;
    els.success.hidden = false;
    var first = String(r.n).split(' ')[0];
    $('success-title').textContent = 'Thank you, ' + first + '!';
    $('success-text').textContent = r.f === 'm'
      ? 'Your monthly donation of ₹' + inr(r.a) + ' is set up. Here is your donor certificate.'
      : 'Your donation of ₹' + inr(r.a) + ' has been received. Here is your donor certificate.';
    $('success-meta').textContent = 'Payment ID: ' + (d.paymentId || 'pay_' + r.i) + (demo ? '' : '. Razorpay has also emailed you a payment receipt.');
    $('success-demo').hidden = !demo;
    $('success-link').value = W.verifyUrl(d.token || 'SAMPLE');
    W.showCertificate(els.success, { record: r, token: d.token, receipt: d.receipt, sample: demo });
    els.success.focus();
    els.success.scrollIntoView({ block: 'start' });
  }

  function resetToForm() {
    if (els.success.hidden) return;
    els.success.hidden = true;
    form.hidden = false;
    form.reset();
    els.f80g.hidden = true;
    update();
  }
  $('donate-again').addEventListener('click', function () { resetToForm(); form.scrollIntoView({ block: 'start' }); });
})();
