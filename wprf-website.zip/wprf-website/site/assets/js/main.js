/* WPRF site: navigation, forms, copy buttons, blog filter, and (preview only) page routing. */
(function () {
  'use strict';
  var CFG = window.WPRF_CONFIG || {};
  var PREVIEW = CFG.mode === 'preview';
  var W = window.WPRF = window.WPRF || {};
  W.preview = PREVIEW;
  W.preset = W.preset || null;

  function $(s, r) { return (r || document).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
  W.$ = $; W.$$ = $$;

  $$('.js-year').forEach(function (el) { el.textContent = new Date().getFullYear(); });

  /* ---------- Toast ---------- */
  W.toast = function (msg) {
    var t = $('#wprf-toast');
    if (!t) {
      t = document.createElement('div');
      t.id = 'wprf-toast'; t.className = 'toast'; t.setAttribute('role', 'status');
      document.body.appendChild(t);
    }
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(t._h);
    t._h = setTimeout(function () { t.classList.remove('show'); }, 3200);
  };

  /* ---------- Header: menu + dropdown ---------- */
  var header = $('#site-header');
  var menuBtn = $('.menu-toggle', header);
  var subToggle = $('.sub-toggle', header);
  function setMenu(open) {
    header.classList.toggle('menu-open', open);
    menuBtn.setAttribute('aria-expanded', String(open));
  }
  function setSub(open) { if (subToggle) subToggle.setAttribute('aria-expanded', String(open)); }
  if (menuBtn) menuBtn.addEventListener('click', function () { setMenu(!header.classList.contains('menu-open')); });
  if (subToggle) {
    subToggle.addEventListener('click', function () { setSub(subToggle.getAttribute('aria-expanded') !== 'true'); });
    var hasSub = subToggle.parentElement;
    var desktop = window.matchMedia('(min-width: 1121px) and (hover: hover)');
    hasSub.addEventListener('mouseenter', function () { if (desktop.matches) setSub(true); });
    hasSub.addEventListener('mouseleave', function () { if (desktop.matches) setSub(false); });
  }
  document.addEventListener('click', function (e) { if (!e.target.closest('.has-sub')) setSub(false); });
  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Escape') return;
    if (subToggle && subToggle.getAttribute('aria-expanded') === 'true') { setSub(false); subToggle.focus(); }
    if (header.classList.contains('menu-open')) { setMenu(false); menuBtn.focus(); }
  });
  $('#site-nav').addEventListener('click', function (e) { if (e.target.closest('a')) { setMenu(false); setSub(false); } });

  /* ---------- Copy to clipboard ---------- */
  function fallbackCopy(text) {
    var ta = document.createElement('textarea');
    ta.value = text; ta.setAttribute('readonly', ''); ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select();
    var ok = false;
    try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
    document.body.removeChild(ta);
    return ok;
  }
  W.copy = function (text) {
    var done = function () { W.toast('Copied: ' + (text.length > 40 ? text.slice(0, 40) + '…' : text)); };
    var fail = function () {
      if (fallbackCopy(text)) done();
      else W.toast('Copy didn\'t work here. Select the text and copy it yourself.');
    };
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(done, fail);
      else fail();
    } catch (e) { fail(); }
  };
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-copy], [data-copy-from]');
    if (!b) return;
    var text = b.hasAttribute('data-copy') ? b.getAttribute('data-copy') : ($('#' + b.getAttribute('data-copy-from')) || {}).value;
    if (text) W.copy(text);
  });

  /* ---------- Form validation (shared with donate.js) ---------- */
  function labelFor(el) {
    var l = el.id && document.querySelector('label[for="' + el.id + '"]');
    if (!l) return 'this field';
    var t = l.cloneNode(true);
    $$('.opt', t).forEach(function (o) { o.remove(); });
    return t.textContent.trim().toLowerCase();
  }
  function errorSlot(el) {
    var field = el.closest('.field');
    if (field) return $('.field-error', field);
    var check = el.closest('.check');
    if (check && check.nextElementSibling && check.nextElementSibling.classList.contains('field-error')) return check.nextElementSibling;
    return null;
  }
  W.setError = function (el, msg) {
    var slot = errorSlot(el);
    if (msg) {
      el.setAttribute('aria-invalid', 'true');
      if (slot) {
        slot.textContent = msg;
        if (!slot.id) slot.id = (el.id || el.name) + '-error';
        el.setAttribute('aria-describedby', ((el.getAttribute('aria-describedby') || '').replace(slot.id, '') + ' ' + slot.id).trim());
      }
    } else {
      el.removeAttribute('aria-invalid');
      if (slot) slot.textContent = '';
    }
  };
  function messageFor(el) {
    var v = el.validity;
    if (el.type === 'checkbox' && v.valueMissing) return 'Please tick this box to continue.';
    if (v.valueMissing) return 'Please enter ' + labelFor(el) + '.';
    if (v.typeMismatch && el.type === 'email') return 'Enter an email address like name@example.com.';
    if (v.patternMismatch && el.type === 'tel') return 'Enter a valid phone number, for example 98765 43210.';
    return el.validationMessage || 'Please check this field.';
  }
  W.validate = function (form, extra) {
    var first = null;
    $$('input, select, textarea', form).forEach(function (el) {
      if (el.closest('[hidden]') || el.type === 'hidden' || el.name === 'bot-field') return;
      var msg = el.checkValidity() ? '' : messageFor(el);
      if (!msg && extra) msg = extra(el) || '';
      W.setError(el, msg);
      if (msg && !first) first = el;
    });
    if (first) first.focus();
    return !first;
  };
  document.addEventListener('input', function (e) {
    var el = e.target;
    if (el.getAttribute && el.getAttribute('aria-invalid') === 'true') W.setError(el, '');
  });
  document.addEventListener('change', function (e) {
    var el = e.target;
    if (el.type === 'checkbox' && el.getAttribute('aria-invalid') === 'true') W.setError(el, '');
  });

  /* ---------- Netlify forms (contact, booking, newsletter) ---------- */
  $$('form.js-form').forEach(function (form) {
    form.setAttribute('novalidate', '');
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!W.validate(form)) return;
      var status = $('.form-status', form);
      var btn = $('[type="submit"]', form);
      btn.disabled = true;
      var finish = function () {
        status.classList.remove('is-error');
        status.textContent = status.getAttribute('data-success') + (PREVIEW ? ' (Preview: nothing was sent.)' : '');
        form.classList.add('form-done');
        btn.disabled = false;
      };
      if (PREVIEW) { setTimeout(finish, 450); return; }
      var body = new URLSearchParams(new FormData(form)).toString();
      fetch('/', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: body })
        .then(function (res) { if (!res.ok) throw new Error('HTTP ' + res.status); finish(); })
        .catch(function () {
          btn.disabled = false;
          status.classList.add('is-error');
          status.textContent = 'We couldn\'t send this. Check your internet connection and try again, or email us at ' + CFG.email + '.';
        });
    });
  });

  /* ---------- Contact topic preset ---------- */
  function applyTopic(topic) {
    var sel = $('#c-topic');
    if (!sel || !topic) return;
    if ($$('option', sel).some(function (o) { return o.value === topic; })) sel.value = topic;
  }
  if (!PREVIEW) applyTopic(new URLSearchParams(location.search).get('topic'));

  /* ---------- Blog filter ---------- */
  $$('.filter').forEach(function (group) {
    var section = group.parentElement;
    group.addEventListener('click', function (e) {
      var chip = e.target.closest('.chip');
      if (!chip) return;
      var f = chip.getAttribute('data-filter');
      $$('.chip', group).forEach(function (c) { c.setAttribute('aria-pressed', String(c === chip)); });
      var shown = 0;
      $$('.post-card', section).forEach(function (card) {
        var match = f === 'all' || (' ' + card.getAttribute('data-cats') + ' ').indexOf(' ' + f + ' ') > -1;
        card.hidden = !match;
        if (match) shown++;
      });
      var empty = $('.filter-empty', section);
      if (empty) empty.hidden = shown > 0;
    });
  });

  /* ---------- Preview: single-file page routing ---------- */
  if (PREVIEW) {
    var routes = $$('.route');
    var byId = {};
    routes.forEach(function (r) { byId[r.getAttribute('data-route')] = r; });
    var show = function (route, scrollTo, push) {
      var sec = byId[route] || byId.home;
      var id = sec.getAttribute('data-route');
      routes.forEach(function (r) { r.hidden = r !== sec; });
      document.body.setAttribute('data-route', id);
      var nav = sec.getAttribute('data-nav');
      $$('a[data-nav]', header).forEach(function (a) {
        if (a.getAttribute('data-nav') === nav && nav !== 'donate') a.setAttribute('aria-current', 'page');
        else a.removeAttribute('aria-current');
      });
      if (subToggle) subToggle.setAttribute('data-current', String(nav === 'work'));
      if (push) { try { history.pushState({ r: id }, '', '#' + id); } catch (e) { /* ignore */ } }
      var target = scrollTo && sec.querySelector('#' + scrollTo);
      if (target) target.scrollIntoView({ block: 'start' });
      else window.scrollTo(0, 0);
      document.dispatchEvent(new CustomEvent('wprf:route', { detail: { route: id, preset: W.preset } }));
      if (id === 'contact' && W.preset) applyTopic(W.preset.topic);
    };
    document.addEventListener('click', function (e) {
      var a = e.target.closest('a[href^="#"]');
      if (!a) return;
      var route = a.getAttribute('href').slice(1);
      if (!byId[route]) return;
      e.preventDefault();
      W.preset = {
        amount: a.getAttribute('data-amount'), freq: a.getAttribute('data-freq'),
        cause: a.getAttribute('data-cause'), topic: a.getAttribute('data-topic')
      };
      show(route, a.getAttribute('data-scroll'), true);
    });
    window.addEventListener('popstate', function () { W.preset = null; show((location.hash || '#home').slice(1), null, false); });
    var initial = (location.hash || '').slice(1);
    if (byId[initial] && initial !== 'home') show(initial, null, false);
    else document.body.setAttribute('data-route', 'home');
  }
})();
