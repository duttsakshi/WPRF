window.WPRF_CONFIG = {
  "mode": "site",
  "orgName": "Well-being and Psychological Research Foundation",
  "short": "WPRF",
  "logo": "assets/img/logo-512.png",
  "address": "107, First Floor, AMC Avenue, NIBM Annexe, Mohammed Wadi, Pune, Maharashtra",
  "email": "wbprfoundation@gmail.com",
  "phone": "+91 95189 55652",
  "legal": {
    "pan": "",
    "reg_80g": "",
    "reg_80g_valid": "",
    "reg_12a": "",
    "cin": "",
    "fcra": false
  },
  "signatory": {
    "name": "Naseem Ahmad",
    "title": "Founder & Director"
  },
  "signature": "",
  "upi": "wellbeingandpsychologicalre7285@aubank",
  "upiName": "Wellbeing & Psychological Research Foundation",
  "stats": {
    "donors": 854,
    "goal": 1500,
    "monthly_raised": 8540
  },
  "minAmount": 10,
  "maxAmount": 500000,
  "causes": {
    "general": "Where it's needed most",
    "therapy": "Therapy Access Fund",
    "youth": "Youth Mental Health Research",
    "training": "Community Training"
  },
  "tiers": {
    "monthly": [
      {
        "amount": 10,
        "name": "Research supporter",
        "impact": "Funds 15 minutes of mental health research every month.",
        "perks": [
          "Monthly research updates"
        ]
      },
      {
        "amount": 50,
        "name": "Education champion",
        "impact": "Adds up to a full therapy session every year for someone who can't afford one.",
        "perks": [
          "Training programme insights",
          "Monthly research updates"
        ]
      },
      {
        "amount": 100,
        "name": "Therapy sponsor",
        "impact": "Helps train a community mental health worker.",
        "perks": [
          "Anonymous success stories",
          "Monthly research updates"
        ]
      },
      {
        "amount": 500,
        "name": "Community leader",
        "impact": "Provides a therapy session every month for someone in need.",
        "perks": [
          "Comprehensive impact reports",
          "Anonymous success stories"
        ]
      }
    ],
    "once": [
      {
        "amount": 500,
        "name": "Basic healing",
        "impact": "Provides one therapy session to someone who can't afford mental healthcare.",
        "perks": [
          "A 50-minute session with a professional therapist",
          "Assessment and a personalised support plan",
          "Follow-up care and progress tracking"
        ]
      },
      {
        "amount": 2000,
        "name": "Transformational support",
        "impact": "Ensures mental healthcare for one person for a full month.",
        "perks": [
          "4 therapy sessions for one client",
          "Personalised coping strategies",
          "Progress tracking for sustained healing"
        ]
      },
      {
        "amount": 5000,
        "name": "Community champion",
        "impact": "Creates community-wide mental health impact.",
        "perks": [
          "10 therapy sessions, or",
          "One mental health workshop for a community group"
        ]
      }
    ]
  },
  "domain": "wprf.in"
};
