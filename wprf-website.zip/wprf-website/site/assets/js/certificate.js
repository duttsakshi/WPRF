/* WPRF donor certificate + 80G receipt: drawn on canvas, exported as PNG or PDF.
   A certificate record looks like:
   { i: payment id without "pay_", n: donor name, a: amount in rupees, f: "o" (one-time) | "m" (monthly),
     c: cause key, d: "YYYY-MM-DD" }                                                               */
(function () {
  'use strict';
  var CFG = window.WPRF_CONFIG || {};
  var W = window.WPRF = window.WPRF || {};
  var PREVIEW = CFG.mode === 'preview';
  var CAUSES = CFG.causes || {};
  var FD = "'Newsreader', 'Iowan Old Style', Georgia, serif";
  var FB = "'Mukta', 'Segoe UI', Roboto, sans-serif";
  var C = { paper: '#FBFCF7', forest: '#0B6B35', deep: '#0C3A21', ink: '#14251A', ink2: '#4B5E51', gold: '#E2A12E', line: '#C9D6C6' };

  /* ---------- helpers ---------- */
  function inr(n) { return Number(n).toLocaleString('en-IN'); }
  function parseDate(d) { var p = String(d).split('-'); return new Date(+p[0], +p[1] - 1, +p[2]); }
  function fmtDate(d) {
    var m = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    var x = parseDate(d); return x.getDate() + ' ' + m[x.getMonth()] + ' ' + x.getFullYear();
  }
  function finYear(d) {
    var x = parseDate(d), s = x.getMonth() >= 3 ? x.getFullYear() : x.getFullYear() - 1;
    return String(s).slice(2) + '-' + String(s + 1).slice(2);
  }
  function certNo(r) { return 'WPRF/' + finYear(r.d) + '/' + String(r.i).toUpperCase(); }
  function receiptNo(r) { return 'WPRF/80G/' + finYear(r.d) + '/' + String(r.i).toUpperCase(); }
  function words(num) {
    var a = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Eleven', 'Twelve', 'Thirteen',
      'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
    var b = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
    function two(n) { return n < 20 ? a[n] : b[Math.floor(n / 10)] + (n % 10 ? ' ' + a[n % 10] : ''); }
    function three(n) { var h = Math.floor(n / 100), r = n % 100; return (h ? a[h] + ' Hundred' + (r ? ' ' : '') : '') + (r ? two(r) : ''); }
    num = Math.floor(num);
    if (!num) return 'Zero';
    var out = [], cr = Math.floor(num / 1e7); num %= 1e7;
    var lk = Math.floor(num / 1e5); num %= 1e5;
    var th = Math.floor(num / 1e3); num %= 1e3;
    if (cr) out.push(three(cr) + ' Crore');
    if (lk) out.push(two(lk) + ' Lakh');
    if (th) out.push(two(th) + ' Thousand');
    if (num) out.push(three(num));
    return out.join(' ');
  }
  function causePhrase(c) {
    if (!c || c === 'general' || !CAUSES[c]) return 'the Well-being and Psychological Research Foundation';
    return 'the ' + CAUSES[c] + ' at the Well-being and Psychological Research Foundation';
  }
  function wrap(ctx, text, max) {
    var out = [], line = '';
    text.split(' ').forEach(function (w) {
      var t = line ? line + ' ' + w : w;
      if (ctx.measureText(t).width > max && line) { out.push(line); line = w; } else line = t;
    });
    if (line) out.push(line);
    return out;
  }
  function spaced(ctx, text, x, y, spacing) {
    // letter-spaced text centred on x (canvas letterSpacing isn't available everywhere)
    var chars = text.split(''), widths = chars.map(function (ch) { return ctx.measureText(ch).width; });
    var total = widths.reduce(function (s, w) { return s + w; }, 0) + spacing * (chars.length - 1);
    var cx = x - total / 2, align = ctx.textAlign;
    ctx.textAlign = 'left';
    chars.forEach(function (ch, i) { ctx.fillText(ch, cx, y); cx += widths[i] + spacing; });
    ctx.textAlign = align;
  }

  var fontsReady = null;
  function loadFonts() {
    if (fontsReady) return fontsReady;
    if (!document.fonts || !document.fonts.load) return (fontsReady = Promise.resolve());
    var sample = 'Certificate ₹1234567890 Aa';
    fontsReady = Promise.all([
      document.fonts.load('600 80px Newsreader', sample),
      document.fonts.load('italic 500 80px Newsreader', sample),
      document.fonts.load('400 30px Mukta', sample),
      document.fonts.load('700 30px Mukta', sample)
    ]).catch(function () {});
    return fontsReady;
  }
  var imgCache = {};
  function loadImage(src) {
    if (!src) return Promise.resolve(null);
    if (imgCache[src]) return imgCache[src];
    imgCache[src] = new Promise(function (res) {
      var im = new Image();
      im.onload = function () { res(im); };
      im.onerror = function () { res(null); };
      im.src = src;
    });
    return imgCache[src];
  }
  function logoSrc() {
    if (CFG.logo) return CFG.logo;
    var el = document.querySelector('.brand img');
    return el ? el.src : null;
  }
  W.verifyUrl = function (token) {
    if (PREVIEW) return 'https://' + (CFG.domain || 'wprf.in') + '/certificate.html?c=' + token;
    var base = location.href.replace(/[?#].*$/, '').replace(/[^/]*$/, '');
    return base + 'certificate.html?c=' + encodeURIComponent(token);
  };

  function drawQR(ctx, text, x, y, size) {
    if (typeof window.qrcode !== 'function') return false;
    var qr = window.qrcode(0, 'M');
    qr.addData(text);
    qr.make();
    var n = qr.getModuleCount(), cell = size / n;
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(x - 10, y - 10, size + 20, size + 20);
    ctx.fillStyle = C.deep;
    for (var r = 0; r < n; r++) for (var c = 0; c < n; c++) {
      if (qr.isDark(r, c)) ctx.fillRect(Math.floor(x + c * cell), Math.floor(y + r * cell), Math.ceil(cell), Math.ceil(cell));
    }
    return true;
  }
  W.qrSvg = function (text) {
    if (typeof window.qrcode !== 'function') return '';
    var qr = window.qrcode(0, 'M'); qr.addData(text); qr.make();
    return qr.createSvgTag(4, 0);
  };

  /* ---------- Certificate (A4 landscape, 2000 x 1414) ---------- */
  function drawCertificate(canvas, r, opts) {
    opts = opts || {};
    return Promise.all([loadFonts(), loadImage(logoSrc()), loadImage(CFG.signature || null)]).then(function (res) {
      var logo = res[1], sig = res[2];
      var W_ = 2000, H = 1414;
      canvas.width = W_; canvas.height = H;
      var ctx = canvas.getContext('2d');
      ctx.textBaseline = 'alphabetic';
      // frame
      ctx.fillStyle = C.forest; ctx.fillRect(0, 0, W_, H);
      ctx.fillStyle = C.paper; ctx.fillRect(30, 30, W_ - 60, H - 60);
      ctx.strokeStyle = C.gold; ctx.lineWidth = 3; ctx.strokeRect(58, 58, W_ - 116, H - 116);
      ctx.strokeStyle = C.line; ctx.lineWidth = 1.5; ctx.strokeRect(70, 70, W_ - 140, H - 140);
      // watermark
      if (logo) { ctx.save(); ctx.globalAlpha = 0.035; ctx.drawImage(logo, W_ / 2 - 430, 300, 860, 860); ctx.restore(); }
      // logo + org
      if (logo) ctx.drawImage(logo, W_ / 2 - 78, 104, 156, 156);
      ctx.textAlign = 'center';
      ctx.fillStyle = C.forest;
      ctx.font = '700 25px ' + FB;
      spaced(ctx, 'WELL-BEING AND PSYCHOLOGICAL RESEARCH FOUNDATION', W_ / 2, 312, 4.5);
      // title
      ctx.fillStyle = C.ink;
      ctx.font = 'italic 500 104px ' + FD;
      ctx.fillText('Certificate of Appreciation', W_ / 2, 440);
      // ornament
      ctx.strokeStyle = C.gold; ctx.lineWidth = 2.5;
      ctx.beginPath(); ctx.moveTo(W_ / 2 - 160, 486); ctx.lineTo(W_ / 2 - 18, 486); ctx.moveTo(W_ / 2 + 18, 486); ctx.lineTo(W_ / 2 + 160, 486); ctx.stroke();
      ctx.fillStyle = C.gold; ctx.beginPath(); ctx.arc(W_ / 2, 486, 7, 0, Math.PI * 2); ctx.fill();
      // presented to
      ctx.fillStyle = C.ink2; ctx.font = '400 32px ' + FB;
      ctx.fillText('This certificate is gratefully presented to', W_ / 2, 562);
      // name
      var size = 100, name = String(r.n || 'Valued donor');
      ctx.font = '600 ' + size + 'px ' + FD;
      while (ctx.measureText(name).width > 1500 && size > 52) { size -= 4; ctx.font = '600 ' + size + 'px ' + FD; }
      ctx.fillStyle = C.forest;
      ctx.fillText(name, W_ / 2, 680);
      ctx.strokeStyle = C.line; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(W_ / 2 - 480, 716); ctx.lineTo(W_ / 2 + 480, 716); ctx.stroke();
      // body
      var amt = '₹' + inr(r.a);
      var body = r.f === 'm'
        ? 'for joining our community of monthly donors with a gift of ' + amt + ' every month to ' + causePhrase(r.c) + '. Your kindness helps make mental healthcare accessible, affordable and free of stigma.'
        : 'in recognition of your generous contribution of ' + amt + ' to ' + causePhrase(r.c) + '. Your kindness helps make mental healthcare accessible, affordable and free of stigma.';
      ctx.fillStyle = C.ink; ctx.font = '400 33px ' + FB;
      wrap(ctx, body, 1360).forEach(function (ln, i) { ctx.fillText(ln, W_ / 2, 792 + i * 50); });
      // bottom row
      var by = 1090;
      ctx.textAlign = 'left';
      ctx.fillStyle = C.ink2; ctx.font = '700 22px ' + FB;
      ctx.fillText('DATE', 190, by); ctx.fillText('CERTIFICATE NO.', 190, by + 108);
      ctx.fillStyle = C.ink; ctx.font = '600 38px ' + FD;
      ctx.fillText(fmtDate(r.d), 190, by + 48);
      ctx.font = '500 32px ' + FD;
      ctx.fillText(certNo(r), 190, by + 154);
      // signatory
      ctx.textAlign = 'center';
      var sx = W_ / 2;
      if (sig) {
        var sh = 110, sw = sig.width * sh / sig.height;
        ctx.drawImage(sig, sx - sw / 2, by - 30, sw, sh);
        ctx.strokeStyle = C.ink2; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.moveTo(sx - 200, by + 92); ctx.lineTo(sx + 200, by + 92); ctx.stroke();
      }
      var sg = CFG.signatory || { name: 'Naseem Ahmad', title: 'Founder & Director' };
      ctx.fillStyle = C.ink; ctx.font = 'italic 500 44px ' + FD;
      ctx.fillText(sg.name, sx, by + 136);
      ctx.fillStyle = C.ink2; ctx.font = '400 26px ' + FB;
      ctx.fillText(sg.title + ', WPRF', sx, by + 176);
      // QR
      var qx = W_ - 190 - 176, qy = by - 50;
      var hasQR = drawQR(ctx, opts.verifyUrl || W.verifyUrl('SAMPLE'), qx, qy, 176);
      if (hasQR) {
        ctx.fillStyle = C.ink2; ctx.font = '700 20px ' + FB;
        ctx.fillText('SCAN TO VERIFY', qx + 88, qy + 216);
      }
      // footer
      ctx.fillStyle = C.ink2; ctx.font = '400 22px ' + FB;
      ctx.fillText('A registered Section 8 non-profit company, Pune, India. Donations are eligible for tax benefit under Section 80G.', W_ / 2, H - 104);
      if (opts.sample) {
        ctx.save(); ctx.translate(W_ / 2, H / 2 + 40); ctx.rotate(-0.28);
        ctx.fillStyle = 'rgba(169, 39, 31, 0.13)'; ctx.font = '700 240px ' + FB;
        ctx.fillText('SAMPLE', 0, 80); ctx.restore();
      }
      return canvas;
    });
  }

  /* ---------- 80G receipt (A4 portrait, 1654 x 2339) ---------- */
  function drawReceipt(canvas, r, rc, opts) {
    opts = opts || {};
    return Promise.all([loadFonts(), loadImage(logoSrc())]).then(function (res) {
      var logo = res[1], legal = CFG.legal || {};
      var W_ = 1654, H = 2339, L = 130, R = W_ - 130;
      canvas.width = W_; canvas.height = H;
      var ctx = canvas.getContext('2d');
      var blank = opts.sample ? 'XXXXXXXXXX' : '(to be added)';
      ctx.fillStyle = '#FFFFFF'; ctx.fillRect(0, 0, W_, H);
      ctx.fillStyle = C.forest; ctx.fillRect(0, 0, W_, 22);
      if (logo) ctx.drawImage(logo, L, 110, 150, 150);
      ctx.textAlign = 'left'; ctx.fillStyle = C.ink;
      ctx.font = '600 46px ' + FD;
      ctx.fillText('Well-being and Psychological', L + 190, 168);
      ctx.fillText('Research Foundation', L + 190, 222);
      ctx.fillStyle = C.ink2; ctx.font = '400 26px ' + FB;
      ctx.fillText(CFG.address || '', L + 190, 268);
      var y = 330;
      ctx.font = '400 25px ' + FB;
      var meta = ['PAN: ' + (legal.pan || blank), '80G registration no.: ' + (legal.reg_80g || blank) + (legal.reg_80g_valid ? ' (valid ' + legal.reg_80g_valid + ')' : '')];
      if (legal.cin) meta.push('CIN: ' + legal.cin);
      meta.forEach(function (m) { ctx.fillText(m, L + 190, y); y += 38; });
      y += 40;
      ctx.strokeStyle = C.line; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(L, y); ctx.lineTo(R, y); ctx.stroke();
      y += 110;
      ctx.fillStyle = C.ink; ctx.font = '600 70px ' + FD; ctx.fillText('Donation receipt', L, y);
      ctx.textAlign = 'right'; ctx.font = '400 26px ' + FB; ctx.fillStyle = C.ink2;
      ctx.fillText('Receipt no. ' + receiptNo(r), R, y - 40);
      ctx.fillText('Date: ' + fmtDate(r.d), R, y);
      ctx.textAlign = 'left';
      y += 90;
      var rows = [
        ['Received with thanks from', r.n],
        ['Address', rc.address || ''],
        ['PAN of donor', (rc.pan || '').toUpperCase()],
        ['Amount', '₹' + inr(rc.amount || r.a) + ' (Rupees ' + words(rc.amount || r.a) + ' only)'],
        ['Mode of payment', 'Online, through Razorpay' + (rc.method ? ' (' + String(rc.method).toUpperCase() + ')' : '')],
        ['Transaction ID', rc.paymentId || ('pay_' + r.i)],
        ['Purpose', 'Donation' + (r.f === 'm' ? ' (monthly)' : '') + ' towards ' + (r.c && r.c !== 'general' && CAUSES[r.c] ? CAUSES[r.c] : 'the objectives of the Foundation')]
      ];
      rows.forEach(function (row) {
        ctx.fillStyle = C.ink2; ctx.font = '700 24px ' + FB; ctx.fillText(row[0].toUpperCase(), L, y);
        ctx.fillStyle = C.ink; ctx.font = '400 34px ' + FB;
        var lines = wrap(ctx, String(row[1] || '-'), R - L);
        lines.forEach(function (ln, i) { ctx.fillText(ln, L, y + 48 + i * 46); });
        y += 48 + lines.length * 46 + 30;
        ctx.strokeStyle = C.line; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(L, y - 8); ctx.lineTo(R, y - 8); ctx.stroke();
        y += 34;
      });
      y += 20;
      ctx.font = '400 29px ' + FB;
      var note = 'Donations to the Well-being and Psychological Research Foundation are eligible for deduction under Section 80G of the Income Tax Act, 1961. A certificate in Form 10BE will be issued after the end of the financial year.';
      var nl = wrap(ctx, note, R - L - 70), bh = 56 + nl.length * 44;
      ctx.fillStyle = '#EEF5EF'; ctx.fillRect(L, y, R - L, bh);
      ctx.fillStyle = C.forest; ctx.fillRect(L, y, 8, bh);
      ctx.fillStyle = C.ink;
      nl.forEach(function (ln, i) { ctx.fillText(ln, L + 40, y + 62 + i * 44); });
      y += bh + 70;
      ctx.fillStyle = C.ink2; ctx.font = '400 25px ' + FB;
      ctx.fillText('This is a computer-generated receipt and does not require a signature.', L, y);
      ctx.fillText('Questions? ' + (CFG.email || '') + ', ' + (CFG.phone || ''), L, y + 40);
      ctx.fillStyle = C.forest; ctx.fillRect(0, H - 22, W_, 22);
      if (opts.sample) {
        ctx.save(); ctx.translate(W_ / 2, H / 2); ctx.rotate(-0.5); ctx.textAlign = 'center';
        ctx.fillStyle = 'rgba(169, 39, 31, 0.12)'; ctx.font = '700 220px ' + FB; ctx.fillText('SAMPLE', 0, 0); ctx.restore();
      }
      return canvas;
    });
  }

  /* ---------- Export ---------- */
  var scriptCache = {};
  function loadScript(src) {
    if (scriptCache[src]) return scriptCache[src];
    scriptCache[src] = new Promise(function (res, rej) {
      var s = document.createElement('script'); s.src = src; s.onload = res;
      s.onerror = function () { s.remove(); delete scriptCache[src]; rej(new Error('Could not load ' + src)); };
      document.head.appendChild(s);
    });
    return scriptCache[src];
  }
  W.loadScript = loadScript;
  function slug(s) { return String(s || 'donor').replace(/[^a-z0-9]+/gi, '-').replace(/^-|-$/g, '').slice(0, 40) || 'donor'; }
  function saveBlob(blob, filename) {
    var url = URL.createObjectURL(blob), a = document.createElement('a');
    a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 4000);
  }
  function previewBlocked(msgEl) {
    var m = 'Downloads work on the live website. This preview window blocks file downloads.';
    if (msgEl) msgEl.textContent = m; else if (W.toast) W.toast(m);
  }
  function toPdf(canvases, filename) {
    return loadScript('assets/vendor/jspdf.umd.min.js').then(function () {
      var JsPDF = window.jspdf.jsPDF, doc = null;
      canvases.forEach(function (cv) {
        var land = cv.width > cv.height, w = land ? 297 : 210, h = land ? 210 : 297;
        if (!doc) doc = new JsPDF({ orientation: land ? 'landscape' : 'portrait', unit: 'mm', format: 'a4', compress: true });
        else doc.addPage('a4', land ? 'landscape' : 'portrait');
        doc.addImage(cv.toDataURL('image/jpeg', 0.93), 'JPEG', 0, 0, w, h);
      });
      doc.save(filename);
    });
  }

  /* Wire the action buttons inside `root` for a given certificate. */
  W.showCertificate = function (root, data) {
    // data: { record, token, receipt, sample }
    var r = data.record, url = data.token ? W.verifyUrl(data.token) : W.verifyUrl('SAMPLE');
    var certCanvas = document.createElement('canvas');
    var msg = root.querySelector('.cert-action-msg');
    var img = root.querySelector('.cert-frame img');
    var p = drawCertificate(certCanvas, r, { verifyUrl: url, sample: data.sample }).then(function () {
      if (img) img.src = certCanvas.toDataURL('image/jpeg', 0.9);
      return certCanvas;
    });
    var recBtn = root.querySelector('[data-cert-action="receipt"]');
    var canReceipt = !!(data.receipt && data.receipt.pan && (data.sample || ((CFG.legal || {}).pan && (CFG.legal || {}).reg_80g)));
    if (recBtn) recBtn.hidden = !canReceipt;
    if (msg) msg.textContent = data.receipt && data.receipt.pan && !canReceipt ? 'We\'ll email your 80G receipt to you within a few days.' : '';
    var wa = root.querySelector('[data-cert-action="whatsapp"]');
    var donateUrl = PREVIEW ? 'https://' + (CFG.domain || 'wprf.in') + '/donate.html' : location.href.replace(/[?#].*$/, '').replace(/[^/]*$/, '') + 'donate.html';
    var shareText = 'I just supported affordable mental healthcare by donating to the Well-being and Psychological Research Foundation (WPRF). You can too: ' + donateUrl;
    if (wa) wa.href = 'https://wa.me/?text=' + encodeURIComponent(shareText);
    var base = 'WPRF-certificate-' + slug(r.n);
    root.onclick = function (e) {
      var b = e.target.closest('[data-cert-action]');
      if (!b) return;
      var act = b.getAttribute('data-cert-action');
      if (act === 'whatsapp') {
        // On phones, share the certificate image itself when the browser allows it.
        if (!PREVIEW && navigator.canShare && window.File) {
          e.preventDefault();
          p.then(function (cv) {
            cv.toBlob(function (blob) {
              var file = new File([blob], base + '.png', { type: 'image/png' });
              if (navigator.canShare({ files: [file] })) navigator.share({ files: [file], text: shareText }).catch(function () {});
              else window.open(wa.href, '_blank', 'noopener');
            }, 'image/png');
          });
        }
        return;
      }
      if (PREVIEW) { previewBlocked(msg); return; }
      if (msg) msg.textContent = 'Preparing your file…';
      var done = function () { if (msg) msg.textContent = 'Downloaded. Check your downloads folder.'; };
      var fail = function () { if (msg) msg.textContent = 'The download didn\'t start. Try again, or use a different browser.'; };
      if (act === 'png') p.then(function (cv) { cv.toBlob(function (b2) { saveBlob(b2, base + '.png'); done(); }, 'image/png'); }).catch(fail);
      if (act === 'pdf') p.then(function (cv) { return toPdf([cv], base + '.pdf'); }).then(done, fail);
      if (act === 'receipt') {
        var rc = document.createElement('canvas');
        drawReceipt(rc, r, data.receipt, { sample: data.sample }).then(function () { return toPdf([rc], 'WPRF-80G-receipt-' + slug(r.n) + '.pdf'); }).then(done, fail);
      }
    };
    return p;
  };
  W.drawCertificate = drawCertificate;
  W.drawReceipt = drawReceipt;

  /* ---------- Sample certificates on the page ---------- */
  function today() { var d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
  W.sampleRecord = function (name, amount, freq, cause) {
    return { i: 'SAMPLE' + String(Date.now()).slice(-6), n: name || 'Priya Sharma', a: amount || 2000, f: freq || 'o', c: cause || 'therapy', d: today() };
  };
  function drawSamples() {
    ['sample-cert', 'sample-cert-2'].forEach(function (id) {
      var cv = document.getElementById(id);
      if (cv) drawCertificate(cv, { i: 'SAMPLE01', n: 'Priya Sharma', a: 2000, f: 'o', c: 'therapy', d: today() }, { sample: true });
    });
  }

  /* ---------- Certificate page ---------- */
  function initCertificatePage() {
    var wrap = document.getElementById('cert-result-wrap');
    if (!wrap) return;
    var banner = document.getElementById('verify-banner');
    function showResult(data, text, bad) {
      wrap.hidden = false;
      banner.className = 'verify-banner' + (bad ? ' is-bad' : '');
      banner.textContent = text;
      var frame = wrap.querySelector('.cert-frame'), actions = document.getElementById('cert-result-actions');
      frame.hidden = !!bad; actions.hidden = !!bad;
      if (!bad) W.showCertificate(wrap, data);
      wrap.scrollIntoView({ block: 'start' });
    }
    function verifyToken(token) {
      if (PREVIEW) {
        showResult({ record: W.sampleRecord(), sample: true }, 'Preview mode: on the live site, this shows whether the certificate is genuine.');
        return;
      }
      fetch('api/certificate?c=' + encodeURIComponent(token)).then(function (res) { return res.json(); }).then(function (d) {
        if (d && d.valid) {
          showResult({ record: d.record, token: token },
            'Verified. This certificate was issued by WPRF to ' + d.record.n + ' for a donation made on ' + fmtDate(d.record.d) + '.');
        } else {
          showResult(null, 'We couldn\'t verify this certificate. The link may be incomplete or altered. Contact us at ' + CFG.email + ' if you need help.', true);
        }
      }).catch(function () {
        showResult(null, 'We couldn\'t check this certificate right now. Check your connection and try again.', true);
      });
    }
    var t = new URLSearchParams(location.search).get('c');
    if (t && !PREVIEW) verifyToken(t);

    var vf = document.getElementById('verify-form');
    vf.addEventListener('submit', function (e) {
      e.preventDefault();
      var v = document.getElementById('v-link').value.trim(), alert = document.getElementById('verify-alert');
      var m = v.match(/[?&]c=([^&#\s]+)/), token = m ? decodeURIComponent(m[1]) : (v.indexOf('.') > 0 ? v : '');
      if (!token) { alert.hidden = false; alert.textContent = 'Paste the full certificate link. It contains "certificate.html?c=".'; return; }
      alert.hidden = true;
      verifyToken(token);
    });

    var rf = document.getElementById('reissue-form');
    rf.addEventListener('submit', function (e) {
      e.preventDefault();
      var pid = rf.paymentId, em = rf.email, alert = rf.querySelector('.form-alert');
      var ok = W.validate(rf, function (el) {
        if (el === pid && !/^pay_[A-Za-z0-9]{6,}$/.test(el.value.trim())) return 'Payment IDs start with "pay_", for example pay_ABC123xyz.';
      });
      if (!ok) return;
      alert.hidden = true;
      var btn = rf.querySelector('[type="submit"]'); btn.disabled = true;
      if (PREVIEW) {
        setTimeout(function () {
          btn.disabled = false;
          showResult({ record: W.sampleRecord(), sample: true, receipt: { pan: 'ABCDE1234F', address: 'Pune, Maharashtra', amount: 2000 } },
            'Preview mode: on the live site, the donor\'s own certificate appears here.');
        }, 500);
        return;
      }
      fetch('api/certificate', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ paymentId: pid.value.trim(), email: em.value.trim() }) })
        .then(function (res) { return res.json().then(function (d) { return { ok: res.ok, d: d }; }); })
        .then(function (x) {
          btn.disabled = false;
          if (!x.ok) { alert.hidden = false; alert.textContent = x.d.message || 'We couldn\'t find that donation.'; return; }
          showResult(x.d, 'Here is your certificate. Thank you for supporting WPRF.');
          try { history.replaceState(null, '', 'certificate.html?c=' + encodeURIComponent(x.d.token)); } catch (err) { /* ignore */ }
        })
        .catch(function () { btn.disabled = false; alert.hidden = false; alert.textContent = 'We couldn\'t reach the server. Check your connection and try again.'; });
    });
  }

  function init() { drawSamples(); initCertificatePage(); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
  W.fmtDate = fmtDate; W.inr = inr;
})();
